<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restablecer Contraseña</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ddebf8; /* Fondo azul claro */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .reset-password-container {
            background-color: #ffffff; /* Fondo blanco para el formulario */
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px;
        }

        .reset-password-container h2 {
            color: #0044cc; /* Azul oscuro para el título */
            margin-bottom: 20px;
        }

        .reset-password-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #6699ff; /* Borde azul claro */
            border-radius: 5px;
            font-size: 16px;
        }

        .reset-password-container input:focus {
            border-color: #0044cc; /* Borde azul oscuro al enfocar */
            outline: none;
        }

        .reset-password-container button {
            width: 100%;
            padding: 10px;
            background-color: #0044cc; /* Fondo azul oscuro */
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }

        .reset-password-container button:hover {
            background-color: #002a80; /* Fondo azul más oscuro al pasar el ratón */
        }

        .reset-password-container p {
            color: #0044cc; /* Azul oscuro para el texto */
            margin-top: 20px;
        }

        .reset-password-container a {
            color: #0044cc; /* Azul oscuro para el enlace */
            text-decoration: none;
        }

        .reset-password-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="reset-password-container">
        <h2>Restablecer Contraseña</h2>
        <form action="#" method="post">
            <div class="form-group">
                <label for="current-password">Current Password</label>
                <input type="password" id="current-password" placeholder="Current Password" required>
            </div>
            <div class="form-group">
                <label for="new-password">New Password</label>
                <input type="password" id="new-password" placeholder="New Password" required>
            </div>
            <div class="form-group">
                <label for="confirm-password">Confirm Password</label>
                <input type="password" id="confirm-password" placeholder="Confirm Password" required>
            </div>
            <button type="submit">Enviar enlace de restablecimiento</button>
        </form>
        <p><a href="{{ route('login') }}">Volver al inicio de sesión</a></p>
    </div>
</body>
</html>