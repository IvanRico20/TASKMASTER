<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ResetpasswordController extends Controller
{
    public function password()
    {
        return view('auth.resetpassword'); 
    }
}
