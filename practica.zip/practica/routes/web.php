<?php

use App\Http\Controllers\IndexController;
use App\Http\Controllers\RegistroController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ResetpasswordController;

Route::get('/', [IndexController::class, 'index']);
Route::get('/registro', [RegistroController::class, 'registro'])->name('registro');
Route::post('/registro', [RegistroController::class, 'registrado'])->name('registro.submit');

Route::get('/login', [LoginController::class, 'login'])->name('login');

Route::get('/reset-password', [ResetpasswordController::class, 'password'])->name('reset-password');