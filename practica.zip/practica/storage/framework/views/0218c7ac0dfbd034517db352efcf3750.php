<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ddebf8; /* Fondo azul claro */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            background-color: #ffffff; /* Fondo blanco para el formulario */
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px;
        }

        .login-container h2 {
            color: #0044cc; /* Azul oscuro para el título */
            margin-bottom: 20px;
        }

        .login-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #6699ff; /* Borde azul claro */
            border-radius: 5px;
            font-size: 16px;
        }

        .login-container input:focus {
            border-color: #0044cc; /* Borde azul oscuro al enfocar */
            outline: none;
        }

        .login-container button {
            width: 100%;
            padding: 10px;
            background-color: #0044cc; /* Fondo azul oscuro */
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }

        .login-container button:hover {
            background-color: #002a80; /* Fondo azul más oscuro al pasar el ratón */
        }

        .login-container p {
            color: #0044cc; /* Azul oscuro para el texto */
            margin-top: 20px;
        }

        .login-container a {
            color: #0044cc; /* Azul oscuro para el enlace */
            text-decoration: none;
        }

        .login-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Iniciar Sesión</h2>
        <form action="#" method="post">
            <input type="text" placeholder="Correo" required>
            <input type="password" placeholder="Contraseña" required>
            <button type="submit">Ingresar</button>
        </form>
        <p>¿Olvidaste tu contraseña? <a href="<?php echo e(route('reset-password')); ?>">Cambiar contraseña</a></p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\sr211\OneDrive\Escritorio\practica\practica\resources\views/auth/login.blade.php ENDPATH**/ ?>