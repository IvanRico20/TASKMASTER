<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TaskMaster - Gestor de Tareas</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa; /* Fondo claro */
            color: #333;
        }

        header {
            background-color: #ffffff; /* Fondo blanco */
            color: #333;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .navbar h1 {
            margin: 0;
            font-size: 2em;
            color: #007bff; /* Azul */
        }

        .navbar a {
            color: #007bff; /* Azul */
            text-decoration: none;
            font-size: 1.2em;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #e9ecef; /* Gris claro */
        }

        .navbar .login-button {
            background-color: #007bff; /* Azul */
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1.2em;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .navbar .login-button:hover {
            background-color: #0056b3; /* Azul más oscuro */
            transform: scale(1.05);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .content {
            display: flex;
            align-items: center;
            gap: 40px;
        }

        .info {
            flex: 1;
        }

        .info h2 {
            font-size: 2.5em;
            color: #007bff; /* Azul */
            margin-bottom: 20px;
        }

        .info p {
            font-size: 1.2em;
            color: #555;
            margin-bottom: 30px;
        }

        .info ul {
            list-style-type: none;
            padding: 0;
        }

        .info ul li {
            font-size: 1.1em;
            color: #555;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }

        .info ul li::before {
            content: "✔";
            color: #007bff; /* Azul */
            margin-right: 10px;
        }

        .image {
            flex: 1;
            text-align: center;
        }

        .image img {
            width: 300px; /* Tamaño fijo para la imagen */
            height: auto; /* Mantiene la proporción */
            /* Quitar bordes redondeados */
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        .cta {
            text-align: center;
            margin: 60px 0;
        }

        .cta h2 {
            font-size: 2.5em;
            margin-bottom: 30px;
            color: #007bff; /* Azul */
        }

        .cta button {
            background-color: #007bff; /* Azul */
            color: white;
            border: none;
            padding: 20px 40px;
            font-size: 1.5em;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .cta button:hover {
            background-color: #0056b3; /* Azul más oscuro */
            transform: scale(1.05);
        }

        footer {
            background-color: #ffffff; /* Fondo blanco */
            color: #333;
            text-align: center;
            padding: 20px 0;
            position: relative;
            width: 100%;
            bottom: 0;
            box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.1);
        }

        footer p {
            margin: 0;
        }

        /* Animaciones */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .content, .cta {
            animation: fadeIn 1s ease-out;
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
            100% {
                transform: scale(1);
            }
        }

        .cta button {
            animation: pulse 2s infinite;
        }
    </style>
</head>
<body>

    <header>
        <div class="navbar">
            <h1>TaskMaster</h1>
            <a href="<?php echo e(route('login')); ?>" class="login-button">Iniciar Sesión</a>
        </div>
    </header>

    <div class="container">
        <section class="content">
            <div class="info">
                <h2>Organiza, Prioriza y Colabora</h2>
                <p>TaskMaster es la herramienta definitiva para gestionar tus tareas de manera eficiente. Con nuestras funciones avanzadas, podrás:</p>
                <ul>
                    <li>Mantener todas tus tareas en un solo lugar.</li>
                    <li>Establecer prioridades y enfocarte en lo importante.</li>
                    <li>Colaborar con tu equipo y compartir tareas fácilmente.</li>
                </ul>
            </div>
            <div class="image">
                <img src="<?php echo e(asset('images/image.png')); ?>" alt="TaskMaster">
            </div>
        </section>

        <section class="cta">
            <h2>¿Listo para ser más productivo?</h2>
            <a href="<?php echo e(route('registro')); ?>">
                <button>Regístrate</button>
            </a>
        </section>
    </div>

    <footer>
        <p>TaskMaster. Todos los derechos reservados.</p>
    </footer>

</body>
</html><?php /**PATH C:\Users\sr211\OneDrive\Escritorio\practica\practica\resources\views/auth/index.blade.php ENDPATH**/ ?>